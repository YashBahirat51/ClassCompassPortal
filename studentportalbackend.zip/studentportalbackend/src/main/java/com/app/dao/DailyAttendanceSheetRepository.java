package com.app.dao;

import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.entities.DailyAttendanceSheet;

@Repository
public interface DailyAttendanceSheetRepository extends JpaRepository<DailyAttendanceSheet, Long> {
    DailyAttendanceSheet findByDate(LocalDate date);
}
