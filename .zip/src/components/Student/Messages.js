// src/components/Messages.js

import React from 'react';

const Messages = () => {
  return (
    <div className="content">
      <h2>Messages</h2>
      {/* Messages content here */}
    </div>
  );
};

export default Messages;
