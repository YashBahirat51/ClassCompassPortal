package com.app.security;
public interface CustomUser {
    String getEmail();
    String getPassword();
    String getRole();
}
