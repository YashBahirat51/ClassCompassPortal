//package com.app;
//
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import com.app.service.PasswordUpdateService;
//
//@Configuration
//public class PasswordUpdateRunner {
//
//    @Bean
//    public CommandLineRunner run(PasswordUpdateService passwordUpdateService) {
//        return args -> {
//            passwordUpdateService.updateAllPasswords();
//        };
//    }
//}
