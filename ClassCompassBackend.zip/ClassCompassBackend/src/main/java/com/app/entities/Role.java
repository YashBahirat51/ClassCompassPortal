package com.app.entities;

public enum Role {
    ROLE_ADMIN,
    ROLE_STUDENT,
    FACULTY; // Add more roles as needed
}
